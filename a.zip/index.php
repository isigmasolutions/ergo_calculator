
<!-- CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

<!-- jQuery and JS bundle w/ Popper.js -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<body class="calculatorbody">

<div class="container">
	  <div class="row calculatorrow">

	  	<div style=" background-color: #C0C0C0;width: 100%;padding: 3%;">

<span style="font-size: 16pt; color: #FFFFFF; font-weight: bolder;">Scan MDC Calculator</span></div>

<span style="font-size: 10pt; color: #000000;padding: 3%;">This utility calculates scan MDCs for select contaminant radionuclides in 
soil for 1-second scaler counts with NaI detectors based on probabilistic MCNPX modeling of detection efficiency 
along with related modifications to the MARSSIM method (see Resource links below for supporting technical 
information).</span>

	  	<div class="col-md-6 calculatorleftside calculatorcommon">
			    <form>
				  <div class="form-group">
				    <label for="ctl00_ContentPlaceHolder1_TextBoxBG">Gross Background (cpm):</label>
				    <input name="ctl00$ContentPlaceHolder1$TextBoxBG" type="text" value="" id="ctl00_ContentPlaceHolder1_TextBoxBG">
				  </div>
				  <div class="form-group">
				    <label for="ctl00_ContentPlaceHolder1_DropDownDet">Detector Type:</label>
				    <select name="ctl00$ContentPlaceHolder1$DropDownDet" onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$DropDownDet\',\'\')', 0)" id="ctl00_ContentPlaceHolder1_DropDownDet" >
							<option value="--Select Detector--">--Select Detector--</option>
							<option selected="selected" value="1">1.25"x1.5"</option>
							<option value="2">2"x2"</option>
							<option value="3">3"x3"</option>

						</select>
				  </div>
				  <div class="form-group">				    
				    <label class="form-check-label" for="ctl00_ContentPlaceHolder1_DropDownCont">Contaminant:</label>
				    	<select name="ctl00$ContentPlaceHolder1$DropDownCont" onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$DropDownCont\',\'\')', 0)" id="ctl00_ContentPlaceHolder1_DropDownCont">
							<option selected="selected" value="--Select Contaminant--">--Select Contaminant--</option>
							<option value="1">Am-241</option>
							<option value="2">Co-60</option>
							<option value="3">Cs-137</option>
							<option value="5">Ra-226 (in equilibrium)</option>
							<option value="7">Th-232 (in equiibrium)</option>

						</select>
				  </div>


				  <div class="form-group">				    
				    <label class="form-check-label" for="ctl00_ContentPlaceHolder1_DropDownDiam">Source Diameter (cm):</label>
				    	<select name="ctl00$ContentPlaceHolder1$DropDownDiam" onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$DropDownDiam\',\'\')', 0)" id="ctl00_ContentPlaceHolder1_DropDownDiam" >

							</select>
				  </div>

				  <div class="form-group">				    
				    <label class="form-check-label" for="ctl00_ContentPlaceHolder1_DropDownHeight">Detector Height (cm):</label>
				    	<select name="ctl00$ContentPlaceHolder1$DropDownHeight" id="ctl00_ContentPlaceHolder1_DropDownHeight" >

								</select>
				    	
				  </div>

				   <div class="form-group">
				    <label for="ctl00_ContentPlaceHolder1_TextScan">Scanning Speed (m/second):</label>
				    <input name="ctl00$ContentPlaceHolder1$TextScan" type="text" value="0.5" id="ctl00_ContentPlaceHolder1_TextScan">
				  </div>

				  <div class="form-group">				    
				    <label class="form-check-label" for="ctl00_ContentPlaceHolder1_DropDownFP">False Positive Proportion:</label>
				    	<select name="ctl00$ContentPlaceHolder1$DropDownFP" id="ctl00_ContentPlaceHolder1_DropDownFP" style="width:100%;">
							<option selected="selected" value="0.05">0.05</option>
							<option value="0.10">0.10</option>
							<option value="0.15">0.15</option>
							<option value="0.20">0.20</option>
							<option value="0.25">0.25</option>
							<option value="0.30">0.30</option>
							<option value="0.35">0.35</option>
							<option value="0.40">0.40</option>
							<option value="0.45">0.45</option>
							<option value="0.50">0.50</option>
							<option value="0.55">0.55</option>
							<option value="0.60">0.60</option>

						</select>
				    	
				  </div>


				  <div class="form-group">				    
				    <label class="form-check-label" for="ctl00_ContentPlaceHolder1_DropDownTP">True Positive Proportion:</label>
				    	<select name="ctl00$ContentPlaceHolder1$DropDownTP" id="ctl00_ContentPlaceHolder1_DropDownTP" style="width:100%;">
							<option value="0.60">0.60</option>
							<option value="0.65">0.65</option>
							<option value="0.70">0.70</option>
							<option value="0.75">0.75</option>
							<option value="0.80">0.80</option>
							<option value="0.85">0.85</option>
							<option value="0.90">0.90</option>
							<option selected="selected" value="0.95">0.95</option>

						</select>
				    	
				  </div>

				  <button type="button" class="btn btn-primary">Calculate</button>
			</form>
		</div>
		<div class="col-md-6 calculatorrightside calculatorcommon">Section 2</div>
	  </div>
  </div>

<style type="text/css">
	.calculatorbody{background: #ccc;}
	.calculatorrow{background: #fff;}
	.calculatorleftside{border: 1px solid;}
	.calculatorcommon{padding: 2%;}

</style>
  </body>